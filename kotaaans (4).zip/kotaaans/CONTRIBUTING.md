# Contributing

Thanks for working on Kotaaans Barbershop. This is a small, dependency-light
codebase with **no build step** — the goal is to keep it that way.

## Getting set up

```bash
npm install
cp .env.example .env   # fill in your Supabase credentials
npm run dev
```

See the [README](README.md) for full setup, including database provisioning.

## Project conventions

- **No bundler / no framework.** The front-end is plain HTML/CSS/JS served by
  Express. Don't introduce a build pipeline unless there's a strong reason.
- **CommonJS on the server** (`require`), **browser globals** on the front-end.
- Keep the **CSP nonce** model intact: any inline `<script>` must use
  `nonce="%%NONCE%%"`, and HTML must be served through a route that injects the
  nonce — never as a raw static file.
- **Security first.** Validate and sanitise all input. Never return internal
  error details to the client. See [SECURITY.md](SECURITY.md).

## Before you push

```bash
npm run lint          # ESLint must pass
npm run format:check  # Prettier (optional locally; not a CI gate)
node --check server.js
```

CI runs lint + syntax checks on Node 18/20/22 and a Docker build. Keep them green.

## Commit messages

Use clear, imperative subjects (e.g. `Fix portfolio reorder off-by-one`). Group
unrelated changes into separate commits.

## Scope of changes

This project ships a fixed, documented feature set (see the README). New
features (online shop, orders, notifications, etc.) are **out of scope** for this
repository unless explicitly requested — please open a discussion first.
