'use strict';

// ESLint flat config (ESLint 9+).
// The project ships as plain files: server.js is CommonJS (Node), the front-end
// scripts run in the browser. We scope globals per environment so `no-undef`
// stays meaningful without a build step.
const js = require('@eslint/js');
const globals = require('globals');

module.exports = [
  {
    ignores: [
      'node_modules/**',
      'img/**',
      'package-lock.json',
      '*.min.js',
    ],
  },

  js.configs.recommended,

  // Server-side (Node, CommonJS)
  {
    files: ['server.js', 'eslint.config.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'commonjs',
      globals: { ...globals.node },
    },
    rules: {
      'no-unused-vars': ['warn', { argsIgnorePattern: '^(req|res|next|_)' }],
      'no-empty': ['warn', { allowEmptyCatch: true }],
      // The input sanitiser intentionally strips ASCII control characters.
      'no-control-regex': 'off',
    },
  },

  // Browser-side front-end scripts. Each is a plain <script>, so they share a
  // global scope at runtime.
  {
    files: ['main.js', 'portfolio.js', 'script.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'script',
      globals: { ...globals.browser },
    },
    rules: {
      'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
      'no-empty': ['warn', { allowEmptyCatch: true }],
    },
  },

  // portfolio.js calls initGalleryToggle(), which is defined in script.js and
  // shared via the global scope at runtime.
  {
    files: ['portfolio.js'],
    languageOptions: {
      globals: { initGalleryToggle: 'readonly' },
    },
  },
];
