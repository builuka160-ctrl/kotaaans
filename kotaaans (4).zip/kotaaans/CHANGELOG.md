# Changelog

All notable changes to this project are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- **Docker** support: multi-stage `Dockerfile` (non-root, healthcheck) and
  `docker-compose.yml` for a one-command local run.
- **Code-quality tooling**: ESLint flat config, Prettier config, `.editorconfig`,
  `.nvmrc`, and `lint` / `format` npm scripts.
- **Continuous integration**: GitHub Actions workflow running lint + syntax
  checks on Node 18/20/22 and a Docker build.
- **Documentation**: `SECURITY.md`, `CONTRIBUTING.md`, `CHANGELOG.md`, and a full
  HTTP API reference in `docs/API.md`.

### Changed
- **README** rewritten to accurately describe the shipped feature set.
- **`.env.example`** trimmed to the variables the server actually reads.

### Notes
- No runtime behaviour was changed in this release — additions are tooling,
  packaging, and documentation only.

## [1.0.0]

### Added
- Public marketing site (`index.html`) with SEO, PWA manifest, and accessibility features.
- Admin panel (`admin.html`) with Supabase Auth login and token refresh.
- Services catalog and portfolio management with server-validated image uploads.
- Hardened Express API: Helmet + nonce CSP, rate limiting, input validation,
  magic-byte image checks, and locked-down static serving.
- Supabase schema with Row-Level Security and a server-only storage bucket.
