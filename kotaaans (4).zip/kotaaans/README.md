# Kotaaans Barbershop — Website & Shop

A complete, production-ready website for a barbershop business: a polished
marketing site, an online shop with an order pipeline, a portfolio gallery,
and a secure admin panel — backed by a hardened Node/Express API and Supabase.

> **Live use case:** Kotaaans Barbershop, Rēzekne (Latvia). Fully localised
> in Latvian, ready to re-brand for any salon or small retailer.

---

## ✨ Features

### Public site (`index.html`)
- Responsive, animated single-page site (hero, services, portfolio, reviews, booking).
- **SEO-ready:** semantic markup, Open Graph + Twitter cards, `schema.org/HairSalon`
  structured data, `sitemap.xml`, `robots.txt`.
- **PWA-ready:** web manifest, theme colour, installable.
- **Accessible:** skip-link, visible focus states, `prefers-reduced-motion` support.
- **Fast:** hero image preload + `fetchpriority`, lazy-loaded media, font preconnect.

### Online shop (`shop.js`)
- Product grid loaded from the API, with image fallbacks.
- Product detail modal with image gallery, thumbnails, and keyboard / history navigation.
- Order form with anti-bot protection (honeypot + time-trap) posting to the API.

### Admin panel (`admin.html`, served at `/admin`)
- Email/password login via Supabase Auth with automatic token refresh.
- Manage the **service catalog** and **portfolio** (create, edit, delete, reorder).
- Drag-free reordering, inline image upload (base64 → validated server-side upload).

### Server API (`server.js`)
- REST endpoints for products, services, portfolio, orders, accounting and settings.
- Optional **Telegram notifications** for new orders and product changes.

---

## 🔐 Security

This codebase ships with defence-in-depth baked in — a major part of its value:

- **Helmet** with a strict, **nonce-based Content-Security-Policy** (no unsafe inline JS).
- **Rate limiting** per concern: global API, login, order, and token-refresh limiters.
- **Auth middleware** validates Supabase JWTs server-side and gates admin access by
  role *and* an email allow-list.
- **Input hardening:** sanitisation, strict URL/ID/date validation, prototype-pollution
  guards, and per-key allow-lists for settings.
- **Image upload validation:** MIME + extension + **magic-byte signature** checks and a
  size cap, stored under randomised filenames.
- **No internal error leakage** — clients get generic messages; details stay in server logs.
- **Row-Level Security** policies (see `supabase/schema.sql`) keep orders, accounting and
  settings server-only while exposing catalog data read-only.
- CORS locked to an explicit origin in production; static serving blocks dotfiles and
  server source.

---

## 🧱 Tech stack

| Layer      | Technology                                    |
|------------|-----------------------------------------------|
| Backend    | Node.js ≥ 18.17, Express 4                     |
| Database   | Supabase (PostgreSQL) + Supabase Auth + Storage |
| Security   | Helmet, express-rate-limit, custom validators  |
| Frontend   | Vanilla HTML / CSS / JS (no build step)        |
| Notifications | Telegram Bot API (optional)                 |

No build tooling, bundler, or framework lock-in — the frontend is plain files.

---

## 📁 Project structure

```
kotaaans/
├── server.js              # Express API + static hosting + security
├── index.html             # Public marketing site + shop
├── admin.html             # Admin panel (served at /admin)
├── shop.js                # Shop grid, product modal, order form
├── main.js                # Site interactions (nav, reveal, tabs)
├── script.js              # Gallery toggle + smooth scroll
├── styles.css             # Public site styles
├── img/                   # Images / portfolio photos
├── robots.txt             # Crawler rules
├── sitemap.xml            # Sitemap
├── manifest.webmanifest   # PWA manifest
├── supabase/
│   └── schema.sql         # Database schema + RLS + storage bucket
├── .env.example           # Documented environment template
└── package.json
```

---

## 🚀 Getting started

### 1. Prerequisites
- Node.js **18.17+**
- A free [Supabase](https://supabase.com) project

### 2. Install
```bash
npm install
```

### 3. Provision the database
Open the Supabase **SQL Editor** and run [`supabase/schema.sql`](supabase/schema.sql).
It creates all tables, indexes, RLS policies, the `product-images` storage bucket,
and default settings.

### 4. Configure environment
```bash
cp .env.example .env
```
Fill in your Supabase URL + keys and admin email(s). See `.env.example` for the full,
documented list of variables.

### 5. Create an admin user
In Supabase **Authentication → Users**, add a user whose email is listed in
`ADMIN_EMAILS` (or set that user's `app_metadata.role` to `"admin"`).

### 6. Run
```bash
npm start          # production
npm run dev        # same entrypoint, for local development
```
Visit `http://localhost:3000` for the site and `http://localhost:3000/admin`
for the panel.

---

## 🌐 API reference (summary)

| Method | Endpoint                              | Auth | Purpose                       |
|--------|---------------------------------------|------|-------------------------------|
| GET    | `/api/products`                       | —    | List shop products            |
| GET    | `/api/services`                       | —    | List service catalog          |
| GET    | `/api/portfolio`                      | —    | List portfolio photos         |
| GET    | `/api/settings`                       | —    | Public site settings          |
| POST   | `/api/order`                          | —    | Place an order (rate-limited) |
| POST   | `/api/auth/login`                     | —    | Admin login                   |
| POST   | `/api/auth/refresh`                   | —    | Refresh access token          |
| CRUD   | `/api/products`, `/api/services`, `/api/portfolio` | ✅ | Manage catalog   |
| CRUD   | `/api/orders`, `/api/accounting/*`    | ✅   | Orders & bookkeeping          |
| POST   | `/api/settings`                       | ✅   | Update site settings          |

✅ = requires a valid admin Bearer token. `GET /healthz` is a health check.

---

## ☁️ Deployment

Runs on any Node host (Railway, Render, Fly.io, a VPS, etc.):

1. Set all environment variables from `.env.example` in the host's dashboard.
2. Set `NODE_ENV=production` and `ALLOWED_ORIGIN=https://your-domain`.
3. Start command: `npm start`.
4. Put the app behind HTTPS (the server already sets HSTS and trusts one proxy hop).

---

## 📦 Re-branding checklist

To repurpose this for another business:
- Replace text/branding in `index.html` and images in `img/`.
- Update contact links (WhatsApp, phone, Instagram, TikTok).
- Update structured data, `sitemap.xml`, `robots.txt`, and `manifest.webmanifest`
  with the new domain and business details.
- Adjust service/product categories in `server.js` and `supabase/schema.sql` if needed.

---

## 📄 License

Proprietary. See [`LICENSE`](LICENSE).
