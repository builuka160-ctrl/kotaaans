# HTTP API Reference

Base URL: `http://localhost:3000` (or your deployed origin).

All responses are JSON. Error responses have the shape:

```json
{ "error": "Human-readable message" }
```

Internal details are never exposed — server errors return a generic
`Internal server error` message and are logged server-side only.

## Authentication

Protected endpoints require a **Supabase access token** as a Bearer header:

```
Authorization: Bearer <access_token>
```

Obtain a token via `POST /api/auth/login`. The user must be an admin — either
`app_metadata.role === "admin"` or an email listed in `ADMIN_EMAILS`.

## Rate limits

| Scope          | Limit                         |
|----------------|-------------------------------|
| All `/api/*`   | 60 requests / minute / IP     |
| Login          | 5 attempts / 15 min (failures)|
| Token refresh  | 30 requests / 15 min          |

Exceeding a limit returns `429` with `{ "error": "Too many requests." }`.

---

## Health

### `GET /healthz`
Liveness probe.

**200**
```json
{ "ok": true }
```

---

## Auth

### `POST /api/auth/login`
Admin login. Rate-limited (5 / 15 min).

**Body**
```json
{ "email": "admin@example.com", "password": "••••••••" }
```

**200**
```json
{
  "token": "<access_token>",
  "refresh_token": "<refresh_token>",
  "expires_in": 3600
}
```

**400** — missing/oversized fields · **401** — invalid credentials.

### `POST /api/auth/refresh`
Exchange a refresh token for a new session. Rate-limited (30 / 15 min).

**Body**
```json
{ "refresh_token": "<refresh_token>" }
```

**200** — same shape as login · **400** — missing token · **401** — session expired.

---

## Services

A service has the shape:

```json
{
  "id": 1,
  "name": "Fade",
  "description": "Clean skin fade",
  "time_label": "30 min",
  "price": 20.0,
  "category": "hair",
  "sort_order": 0,
  "img_url": "https://.../product-images/....jpg"
}
```

`category` is one of `hair`, `beard`, `extra` (defaults to `hair`).

### `GET /api/services`
Public. Returns all services ordered by `category`, `sort_order`, `created_at`.

**200** — `Service[]`

### `POST /api/services` 🔒
Create a service.

**Body**
```json
{
  "name": "Fade",
  "description": "Clean skin fade",
  "time_label": "30 min",
  "price": 20,
  "category": "hair",
  "img_url": "https://...",        // optional
  "img_base64": "data:image/jpeg;base64,..." // optional, takes precedence
}
```

`name` is required. `price` must be a finite number in `[0, 100000]`.
If `img_base64` is supplied it is validated (MIME + magic bytes + ≤ 5 MB) and
uploaded server-side.

**201** — the created `Service` · **400** — invalid input.

### `PATCH /api/services/:id` 🔒
Partial update. Only the fields present in the body are changed. Same validation
rules as create.

**200** — the updated `Service` · **400** — invalid id/price.

### `DELETE /api/services/:id` 🔒
**200**
```json
{ "success": true }
```

---

## Portfolio

A portfolio photo has the shape:

```json
{ "id": 1, "img_url": "https://.../....jpg", "sort_order": 0 }
```

### `GET /api/portfolio`
Public. Returns all photos ordered by `sort_order`.

**200** — `Photo[]`

### `POST /api/portfolio` 🔒
Add a photo, either by HTTPS URL or base64 upload.

**Body**
```json
{ "img_base64": "data:image/jpeg;base64,..." }
```
or
```json
{ "img_url": "https://example.com/photo.jpg" }
```

`img_base64` is validated (MIME + magic bytes + ≤ 15 MB) and uploaded
server-side. `img_url` must be HTTPS. New photos are appended (highest
`sort_order + 1`).

**201** — the created `Photo` · **400** — invalid or oversized image / invalid URL.

### `PATCH /api/portfolio/:id` 🔒
Replace a photo's image (same body options as `POST`).

**200** — the updated `Photo` · **400** — invalid input.

### `PATCH /api/portfolio/reorder` 🔒
Bulk-set the display order.

**Body**
```json
{ "order": [ { "id": 3, "sort_order": 0 }, { "id": 1, "sort_order": 1 } ] }
```

Max 500 items; malformed entries are skipped.

**200**
```json
{ "success": true }
```

### `DELETE /api/portfolio/:id` 🔒
**200**
```json
{ "success": true }
```

---

🔒 = requires a valid admin Bearer token.
