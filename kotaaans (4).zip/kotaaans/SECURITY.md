# Security Policy

Security is a first-class concern in this codebase. This document describes the
hardening that ships by default, the threat model it addresses, and how to
report a vulnerability.

## Supported versions

| Version | Supported |
|---------|-----------|
| 1.x     | ✅        |

## Reporting a vulnerability

Please report security issues **privately** to the maintainer rather than
opening a public issue. Include:

- a description of the issue and its impact,
- steps to reproduce (a proof-of-concept if possible),
- affected endpoint(s) or file(s).

You can expect an initial acknowledgement within a few business days.

## What ships hardened

### Transport & headers
- **Helmet** sets a strict baseline of security headers.
- **Content-Security-Policy** is **nonce-based** — inline scripts must carry a
  per-request nonce; there is no `unsafe-inline` for JavaScript.
- **HSTS** (1 year, `includeSubDomains`, `preload`).
- `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`,
  `X-Frame-Options: DENY`, and a restrictive `Permissions-Policy`.
- `x-powered-by` is disabled.

### Authentication & authorization
- Admin endpoints require a valid **Supabase JWT**, validated server-side.
- Access is granted only to users with `app_metadata.role === "admin"` **or**
  an email present in the `ADMIN_EMAILS` allow-list.
- Tokens are basic-shape-validated (three-segment JWT, minimum length) before
  the auth call.

### Rate limiting
- Global API limiter (60 req/min/IP).
- Login limiter (5 attempts / 15 min, successful requests not counted).
- Token-refresh limiter (30 / 15 min).

### Input handling
- String **sanitisation** (control-character stripping, length caps).
- Strict validators for **IDs**, **URLs** (HTTPS-only), and **dates**.
- **Prototype-pollution** guards on settings-style keys.
- JSON body size limits (50 KB default, 30 MB for image-bearing routes).

### File uploads
- Images are accepted as base64 and validated by **MIME type + extension +
  magic-byte signature** before upload.
- Size caps: 5 MB (service images), 15 MB (portfolio images).
- Stored under randomised filenames in a dedicated Supabase Storage bucket;
  **writes are server-only** (service-role key), never from the browser.

### Data access
- **Row-Level Security** is enabled on all tables. The public (anon) role has
  **read-only** access to catalog data; all writes go through the server.

### Error handling
- Clients receive generic error messages; internal details are logged
  server-side only.

### Static serving
- Dotfiles, server source, `node_modules`, the `supabase/` directory, and raw
  `.html` templates are **excluded** from static serving (HTML is only served
  through routes that inject the CSP nonce).

## Operational responsibilities (deployer)

These are **not** handled by the code and must be configured by whoever deploys it:

- **Terminate TLS** in front of the app (HSTS assumes HTTPS).
- Set `NODE_ENV=production` and a correct `ALLOWED_ORIGIN`.
- Keep `SUPABASE_SERVICE_KEY` strictly server-side; **never** ship it to a client.
- **Rotate any credentials** that may have been exposed (e.g. committed `.env`
  files). Treat the service-role key as highly sensitive.
- Keep dependencies patched (`npm audit`).
