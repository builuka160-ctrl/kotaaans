(function () {
  const loader = document.getElementById('loader');
  if (!loader) return;
  const hide = () => {
    loader.classList.add('loader-hide');
    setTimeout(() => loader.remove(), 750);
  };
  const minWait  = new Promise(r => setTimeout(r, 2000));
  const pageLoad = new Promise(r => {
    if (document.readyState === 'complete') r();
    else window.addEventListener('load', r, { once: true });
  });
  Promise.all([minWait, pageLoad]).then(hide);
})();

const nav = document.getElementById('nav');
const burger = document.getElementById('burger');
const navLinks = document.getElementById('nav-links');

if (nav) {
  window.addEventListener('scroll', () => {
    nav.classList.toggle('nav-scrolled', window.scrollY > 80);
  });
}

if (burger && nav) {
  burger.addEventListener('click', () => {
    nav.classList.toggle('nav-open');
  });
}

if (navLinks && nav) {
  navLinks.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => nav.classList.remove('nav-open'));
  });
}

function showSiteToast(message, duration = 3200) {
  const toast = document.getElementById('site-toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), duration);
}

function trackEvent(action, label = '', value = 0) {
  if (typeof gtag !== 'function') return;
  gtag('event', action, {
    event_category: 'engagement',
    event_label: label,
    value,
  });
}

function initSectionTracking() {
  if (typeof gtag !== 'function') return;
  const sections = document.querySelectorAll('section[id]');
  const sectionObserver = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        trackEvent('section_view', entry.target.id, 1);
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });
  sections.forEach(el => sectionObserver.observe(el));
}

function easeOutQuad(t) {
  return t * (2 - t);
}

function animateValue(el, target) {
  const start = 0;
  const duration = 1200;
  const startTime = performance.now();
  const step = () => {
    const now = performance.now();
    const progress = Math.min((now - startTime) / duration, 1);
    el.textContent = Math.round(start + (target - start) * easeOutQuad(progress));
    if (progress < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

function initCounters() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const target = Number(entry.target.dataset.count);
      if (Number.isFinite(target)) animateValue(entry.target, target);
      obs.unobserve(entry.target);
    });
  }, { threshold: 0.5 });
  counters.forEach(el => observer.observe(el));
}

function initExitIntentToast() {
  let shown = false;
  document.addEventListener('mouseleave', e => {
    if (shown) return;
    if (e.clientY <= 0 || e.clientX <= 0 || e.clientX >= window.innerWidth) {
      shown = true;
      showSiteToast('Не ушёл? Запишись за 30 сек →');
    }
  });
}

function initGsap() {
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
  gsap.registerPlugin(ScrollTrigger);
  gsap.from('.section-title', {
    y: 60,
    opacity: 0,
    duration: 1,
    ease: 'power3.out',
    stagger: 0.12,
    scrollTrigger: {
      trigger: '.section-title',
      start: 'top 80%',
      toggleActions: 'play none none none'
    }
  });
}

document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const href = a.getAttribute('href');
    if (!href || href === '#') return;
    const target = document.querySelector(href);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

document.querySelectorAll('a[href*="wa.me"]').forEach(a => {
  a.addEventListener('click', () => trackEvent('whatsapp_click', a.href, 1));
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('revealed');
      observer.unobserve(e.target);
    }
  });
}, { threshold: 0.06 });

document.querySelectorAll('.m-item, .review-card, .fact, .reveal').forEach(el => {
  el.classList.add('reveal-item');
  observer.observe(el);
});

window.observeReveal = function(el) {
  el.classList.add('reveal-item');
  observer.observe(el);
};

document.addEventListener('DOMContentLoaded', () => {
  initGsap();
  initCounters();
  initExitIntentToast();
  initSectionTracking();
});
