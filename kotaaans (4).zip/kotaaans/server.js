require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const helmet    = require('helmet');
const rateLimit = require('express-rate-limit');
const path      = require('path');
const fs        = require('fs');
const crypto    = require('crypto');
const { createClient } = require('@supabase/supabase-js');

const app  = express();
const PORT = process.env.PORT || 3000;

const REQUIRED_ENV = ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_KEY'];
const missing = REQUIRED_ENV.filter(k => !process.env[k]);
if (missing.length) {
  console.error('Missing required env vars:', missing.join(', '));
  process.exit(1);
}
if (process.env.NODE_ENV === 'production' && !process.env.ALLOWED_ORIGIN) {
  console.error('ALLOWED_ORIGIN must be set in production');
  process.exit(1);
}

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_PORTFOLIO_BYTES = 15 * 1024 * 1024;
const ALLOWED_IMAGE_EXT = new Set(['jpeg', 'jpg', 'png', 'webp', 'gif']);

function sanitise(s, maxLen = 1000) {
  return String(s ?? '')
    .replace(/\0/g, '')
    .replace(/[\x01-\x08\x0b\x0c\x0e-\x1f\x7f]/g, '')
    .slice(0, maxLen);
}

function sanitiseUrl(url) {
  if (!url) return null;
  try {
    const u = new URL(String(url).trim());
    return u.protocol === 'https:' ? u.href : null;
  } catch { return null; }
}

function parseId(s) {
  const n = parseInt(s, 10);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function isValidDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function isSafeKey(k) {
  return typeof k === 'string' && k.length < 100 && !['__proto__', 'constructor', 'prototype'].includes(k);
}

function tgEscape(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

async function sendTelegramAsync(text) {
  const token  = process.env.TG_BOT_TOKEN;
  const chatId = process.env.TG_CHAT_ID;
  if (!token || !chatId) return;
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' }),
    });
  } catch (e) { console.warn('TG error:', e.message); }
}

async function uploadImage(base64, maxBytes = MAX_IMAGE_BYTES) {
  if (!base64 || typeof base64 !== 'string') return null;
  const match = base64.match(/^data:image\/([a-zA-Z0-9]+);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return null;
  let ext = match[1].toLowerCase();
  if (ext === 'jpg') ext = 'jpeg';
  if (!ALLOWED_IMAGE_EXT.has(ext)) return null;
  let buf;
  try { buf = Buffer.from(match[2], 'base64'); } catch { return null; }
  if (!buf.length || buf.length > maxBytes) return null;

  const sigs = {
    jpeg: [0xFF, 0xD8, 0xFF],
    png:  [0x89, 0x50, 0x4E, 0x47],
    gif:  [0x47, 0x49, 0x46, 0x38],
    webp: null, // checked separately
  };
  const sig = sigs[ext];
  if (sig && !sig.every((b, i) => buf[i] === b)) return null;
  if (ext === 'webp' && !(buf.slice(0, 4).toString('ascii') === 'RIFF' && buf.slice(8, 12).toString('ascii') === 'WEBP')) return null;

  const fileName = `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.${ext}`;
  const { error } = await supabaseAdmin.storage
    .from('product-images')
    .upload(fileName, buf, { contentType: `image/${ext}`, upsert: false });
  if (error) { console.error('Upload error:', error.message); return null; }
  const { data: { publicUrl } } = supabaseAdmin.storage
    .from('product-images')
    .getPublicUrl(fileName);
  return publicUrl;
}

function sendHtmlWithNonce(res, filePath) {
  try {
    const html    = fs.readFileSync(filePath, 'utf8');
    const nonce   = res.locals.cspNonce || '';
    const gaId    = process.env.GA_MEASUREMENT_ID || '';
    const out     = html
      .replace(/%%NONCE%%/g, nonce)
      .replace(/%%GA_MEASUREMENT_ID%%/g, gaId);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(out);
  } catch (e) {
    console.error('HTML serve error:', e.message);
    res.status(500).send('Internal server error');
  }
}

app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use((req, res, next) => {
  res.locals.cspNonce = crypto.randomBytes(16).toString('base64');
  next();
});

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:   ["'self'"],
      scriptSrc:    ["'self'", (req, res) => `'nonce-${res.locals.cspNonce}'`, "https://cdnjs.cloudflare.com", "https://www.googletagmanager.com"],
      scriptSrcAttr:["'none'"],
      styleSrc:     ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://fonts.gstatic.com"],
      fontSrc:      ["'self'", "https://fonts.gstatic.com"],
      imgSrc:       ["'self'", "data:", "https:", "blob:"],
      connectSrc:   ["'self'", "https://*.supabase.co", "https://www.google-analytics.com"],
      frameSrc:     ["'self'", "https://player.vimeo.com"],
      objectSrc:    ["'none'"],
      baseUri:      ["'self'"],
      formAction:   ["'self'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  crossOriginEmbedderPolicy: false,
  xFrameOptions: { action: 'deny' },
}));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'http://localhost:3000';
app.use(cors({
  origin: (origin, cb) => {
    const allowed = [ALLOWED_ORIGIN];
    if (process.env.NODE_ENV !== 'production') {
      allowed.push('http://localhost:3000', 'http://127.0.0.1:3000');
    }
    if (!origin || allowed.includes(origin)) return cb(null, true);
    cb(null, false);
  },
  credentials: false,
}));

const jsonSmall = express.json({ limit: '50kb' });
const jsonLarge = express.json({ limit: '30mb' });
app.use((req, res, next) => {
  const bigRoutes = ['/api/products', '/api/portfolio', '/api/services'];
  const isBig = bigRoutes.some(r => req.path === r || req.path.startsWith(r + '/'));
  if (isBig && ['POST', 'PATCH'].includes(req.method)) {
    return jsonLarge(req, res, next);
  }
  return jsonSmall(req, res, next);
});

// Body parsers leave req.body undefined when Content-Type doesn't match —
// default it to {} so handlers can safely destructure. (The /api/settings
// handler validates object shape itself before iterating entries.)
app.use((req, res, next) => {
  if (req.body == null) req.body = {};
  next();
});

app.use((err, req, res, next) => {
  if (err.status === 413 || err.type === 'entity.too.large') {
    return res.status(413).json({ error: 'Payload too large (max ~30 MB).' });
  }
  if (err instanceof SyntaxError && err.status === 400) {
    return res.status(400).json({ error: 'Invalid JSON' });
  }
  next(err);
});

app.use((req, res, next) => {
  try { decodeURIComponent(req.path); next(); }
  catch { res.status(400).end(); }
});

const apiLimiter = rateLimit({
  windowMs: 60_000, max: 60,
  standardHeaders: true, legacyHeaders: false,
  handler: (req, res) => res.status(429).json({ error: 'Too many requests.' }),
});
app.use('/api/', apiLimiter);

const loginLimiter = rateLimit({
  windowMs: 15 * 60_000, max: 5,
  skipSuccessfulRequests: true,
  handler: (req, res) => res.status(429).json({ error: 'Too many login attempts. Try again in 15 minutes.' }),
});

const orderLimiter = rateLimit({
  windowMs: 60_000, max: 3,
  handler: (req, res) => res.status(429).json({ error: 'Too many requests, please wait.' }),
});

const refreshLimiter = rateLimit({
  windowMs: 15 * 60_000, max: 30,
  handler: (req, res) => res.status(429).json({ error: 'Too many refresh attempts.' }),
});

async function requireAuth(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No auth token' });
  }
  const token = auth.split(' ')[1];
  if (!token || token.length < 20 || token.split('.').length !== 3) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  const ADMIN_EMAILS = new Set(
    (process.env.ADMIN_EMAILS || '').split(',').map(e => e.trim().toLowerCase()).filter(Boolean)
  );
  const role  = data.user.app_metadata?.role;
  const email = (data.user.email || '').toLowerCase();
  const isAdmin = role === 'admin' || (ADMIN_EMAILS.size > 0 && ADMIN_EMAILS.has(email));
  if (!isAdmin) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  req.user = data.user;
  next();
}

app.get('/healthz', (req, res) => res.json({ ok: true }));

app.get(['/admin', '/admin/'], (req, res) => {
  sendHtmlWithNonce(res, path.join(__dirname, 'admin.html'));
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }
  if (email.length > 320 || password.length > 200) {
    return res.status(400).json({ error: 'Invalid input' });
  }
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return res.status(401).json({ error: 'Invalid email or password' });
  res.json({
    token:         data.session.access_token,
    refresh_token: data.session.refresh_token,
    expires_in:    data.session.expires_in,
  });
});

app.post('/api/auth/refresh', refreshLimiter, async (req, res) => {
  const { refresh_token } = req.body || {};
  if (typeof refresh_token !== 'string' || !refresh_token) {
    return res.status(400).json({ error: 'refresh_token required' });
  }
  const { data, error } = await supabase.auth.refreshSession({ refresh_token });
  if (error) return res.status(401).json({ error: 'Session expired' });
  res.json({
    token:         data.session.access_token,
    refresh_token: data.session.refresh_token,
    expires_in:    data.session.expires_in,
  });
});

app.get('/api/client-config', (req, res) => {
  res.json({
    supabaseUrl: process.env.SUPABASE_URL,
    supabaseKey: process.env.SUPABASE_ANON_KEY,
  });
});

app.get('/api/portfolio', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('portfolio_photos')
      .select('id, img_url, sort_order')
      .order('sort_order', { ascending: true });
    if (error) {
      console.error('[portfolio GET]', error.message);
      return res.status(500).json({ error: 'Internal server error' });
    }
    res.json(data || []);
  } catch (e) {
    console.error('[portfolio GET crash]', e.message);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/portfolio', requireAuth, async (req, res) => {
  const { img_url, img_base64 } = req.body;
  let safeUrl;
  if (img_base64) {
    safeUrl = await uploadImage(img_base64, MAX_PORTFOLIO_BYTES);
    if (!safeUrl) return res.status(400).json({ error: 'Invalid or oversized image' });
  } else {
    safeUrl = sanitiseUrl(img_url);
    if (!safeUrl) return res.status(400).json({ error: 'Invalid URL' });
  }
  const { data: last } = await supabaseAdmin
    .from('portfolio_photos').select('sort_order').order('sort_order', { ascending: false }).limit(1);
  const nextOrder = last?.length ? last[0].sort_order + 1 : 0;
  const { data, error } = await supabaseAdmin
    .from('portfolio_photos').insert([{ img_url: safeUrl, sort_order: nextOrder }]).select().single();
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.status(201).json(data);
});

app.patch('/api/portfolio/reorder', requireAuth, async (req, res) => {
  const { order } = req.body;
  if (!Array.isArray(order)) return res.status(400).json({ error: 'order must be an array' });
  if (order.length > 500) return res.status(400).json({ error: 'Too many items' });
  for (const item of order) {
    if (!item || typeof item !== 'object') continue;
    const id = parseId(item.id);
    if (!id) continue;
    const so = parseInt(item.sort_order, 10);
    await supabaseAdmin.from('portfolio_photos')
      .update({ sort_order: Number.isFinite(so) ? so : 0 }).eq('id', id);
  }
  res.json({ success: true });
});

app.patch('/api/portfolio/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { img_url, img_base64 } = req.body;
  let safeUrl;
  if (img_base64) {
    safeUrl = await uploadImage(img_base64, MAX_PORTFOLIO_BYTES);
    if (!safeUrl) return res.status(400).json({ error: 'Invalid or oversized image' });
  } else {
    safeUrl = sanitiseUrl(img_url);
    if (!safeUrl) return res.status(400).json({ error: 'Invalid URL' });
  }
  const { data, error } = await supabaseAdmin
    .from('portfolio_photos').update({ img_url: safeUrl }).eq('id', id).select().single();
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json(data);
});

app.delete('/api/portfolio/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { error } = await supabaseAdmin.from('portfolio_photos').delete().eq('id', id);
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json({ success: true });
});

app.get('/api/services', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('services')
      .select('id, name, description, time_label, price, category, sort_order, img_url')
      .order('category').order('sort_order').order('created_at');
    if (error) { console.error('[services GET]', error.message); return res.status(500).json({ error: 'Internal server error' }); }
    res.json(data || []);
  } catch (e) { console.error('[services GET crash]', e.message); res.status(500).json({ error: 'Internal server error' }); }
});

app.post('/api/services', requireAuth, async (req, res) => {
  const { name, description, time_label, price, category, img_url, img_base64 } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  const parsedPrice = price ? parseFloat(price) : 0;
  if (!Number.isFinite(parsedPrice) || parsedPrice < 0 || parsedPrice > 100000) return res.status(400).json({ error: 'Invalid price' });
  const CATS = ['hair', 'beard', 'extra'];
  let finalImgUrl = sanitiseUrl(img_url) || null;
  if (img_base64) {
    const uploaded = await uploadImage(img_base64);
    if (uploaded) finalImgUrl = uploaded;
  }
  const { data, error } = await supabaseAdmin.from('services').insert([{
    name: sanitise(name, 200),
    description: sanitise(description || '', 500),
    time_label: sanitise(time_label || '', 50),
    price: parsedPrice,
    category: CATS.includes(category) ? category : 'hair',
    img_url: finalImgUrl,
  }]).select().single();
  if (error) { console.error('[services POST]', error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.status(201).json(data);
});

app.patch('/api/services/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { name, description, time_label, price, category, sort_order, img_url, img_base64 } = req.body;
  const CATS = ['hair', 'beard', 'extra'];
  const updates = {};
  if (name !== undefined)        updates.name        = sanitise(name, 200);
  if (description !== undefined) updates.description = sanitise(description, 500);
  if (time_label !== undefined)  updates.time_label  = sanitise(time_label, 50);
  if (category !== undefined)    updates.category    = CATS.includes(category) ? category : 'hair';
  if (price !== undefined) {
    const p = parseFloat(price);
    if (!Number.isFinite(p) || p < 0 || p > 100000) return res.status(400).json({ error: 'Invalid price' });
    updates.price = p;
  }
  if (sort_order !== undefined) {
    const s = parseInt(sort_order, 10);
    if (Number.isFinite(s)) updates.sort_order = s;
  }
  if (img_base64) {
    const uploaded = await uploadImage(img_base64);
    if (uploaded) updates.img_url = uploaded;
  } else if (img_url !== undefined) {
    updates.img_url = sanitiseUrl(img_url) || null;
  }
  const { data, error } = await supabaseAdmin.from('services').update(updates).eq('id', id).select().single();
  if (error) { console.error('[services PATCH]', error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json(data);
});

app.delete('/api/services/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { error } = await supabaseAdmin.from('services').delete().eq('id', id);
  if (error) { console.error('[services DELETE]', error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json({ success: true });
});

const CATEGORIES = ['Haircare', 'Accessories', 'Merch', 'Other'];

app.get('/api/products', async (req, res) => {
  const { data, error } = await supabase
    .from('products')
    .select('id, name, price, description, emoji, img_url, gallery, category, available_sizes, tags, payment_url, is_preorder, created_at')
    .order('created_at', { ascending: false })
    .limit(200);
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json(data);
});

app.post('/api/products', requireAuth, async (req, res) => {
  const { name, price, description, emoji, img_base64, gallery_base64, payment_url, is_preorder, category, available_sizes, tags } = req.body;
  const safeCategory = CATEGORIES.includes(category) ? category : 'Other';
  if (!name || !price) return res.status(400).json({ error: 'Name and price are required' });
  const parsedPrice = parseFloat(price);
  if (!Number.isFinite(parsedPrice) || parsedPrice <= 0 || parsedPrice > 100000) {
    return res.status(400).json({ error: 'Invalid price' });
  }
  const safeEmoji = emoji ? String(emoji).replace(/[<>&"']/g, '').slice(0, 10) : '📦';

  let img_url = null;
  if (img_base64) {
    img_url = await uploadImage(img_base64);
    if (!img_url) return res.status(400).json({ error: 'Invalid or oversized image' });
  }

  let gallery = [];
  if (gallery_base64 && Array.isArray(gallery_base64)) {
    for (const b64 of gallery_base64.slice(0, 4)) {
      const url = await uploadImage(b64);
      if (url) gallery.push(url);
    }
  }

  const safeTags = Array.isArray(tags) ? tags.map(t => String(t).slice(0, 30)).slice(0, 10) : [];

  const { data, error } = await supabaseAdmin
    .from('products')
    .insert([{
      name:            sanitise(name, 300),
      price:           parsedPrice,
      description:     sanitise(description || '', 2000),
      emoji:           safeEmoji,
      img_url,
      gallery,
      payment_url:     sanitiseUrl(payment_url),
      is_preorder:     is_preorder === true,
      category:        safeCategory,
      available_sizes: Array.isArray(available_sizes) ? available_sizes.map(s => String(s).slice(0, 10)).slice(0, 20) : [],
      tags:            safeTags,
    }])
    .select()
    .single();

  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  sendTelegramAsync(
    `➕ <b>Jauns produkts pievienots</b>\n` +
    `ID: <code>${data.id}</code> · <b>${tgEscape(data.name)}</b> · €${data.price}\n` +
    `Admin: <code>${tgEscape(req.user.email)}</code>`
  );
  res.status(201).json(data);
});

// ── PRODUCTS — PATCH (auth) ──────────────────
app.patch('/api/products/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { name, price, description, payment_url, is_preorder, category, img_base64, sort_order, available_sizes, tags } = req.body;
  const updates = {};
  if (name !== undefined)        updates.name        = sanitise(name, 300);
  if (description !== undefined) updates.description = sanitise(description, 2000);
  if (payment_url !== undefined) updates.payment_url = sanitiseUrl(payment_url);
  if (is_preorder !== undefined) updates.is_preorder = is_preorder === true;
  if (category !== undefined)    updates.category    = CATEGORIES.includes(category) ? category : 'Other';
  if (sort_order !== undefined) {
    const s = parseInt(sort_order, 10);
    if (Number.isFinite(s)) updates.sort_order = s;
  }
  if (price !== undefined) {
    const p = parseFloat(price);
    if (!Number.isFinite(p) || p <= 0 || p > 100000) return res.status(400).json({ error: 'Invalid price' });
    updates.price = p;
  }
  if (available_sizes !== undefined) {
    updates.available_sizes = Array.isArray(available_sizes)
      ? available_sizes.map(s => String(s).slice(0, 10)).slice(0, 20) : [];
  }
  if (tags !== undefined) {
    updates.tags = Array.isArray(tags) ? tags.map(t => String(t).slice(0, 30)).slice(0, 10) : [];
  }
  if (img_base64) {
    const url = await uploadImage(img_base64);
    if (url) updates.img_url = url;
  }
  const { data, error } = await supabaseAdmin.from('products').update(updates).eq('id', id).select().single();
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json(data);
});

// ── PRODUCTS — DELETE (auth) ─────────────────
app.delete('/api/products/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { error } = await supabaseAdmin.from('products').delete().eq('id', id);
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  sendTelegramAsync(`🗑 <b>Produkts dzēsts</b>\nID: <code>${id}</code>\nAdmin: <code>${tgEscape(req.user.email)}</code>`);
  res.json({ success: true });
});

// ── ORDER ────────────────────────────────────
app.post('/api/order', orderLimiter, async (req, res) => {
  const { name, contact, address, size, message, product_id, payment_intent, _hp, _ft } = req.body;

  if (_hp) return res.status(403).json({ error: 'Bot detected.' });
  if (typeof _ft !== 'number' || _ft < 2000 || _ft > 1_800_000) {
    return res.status(403).json({ error: 'Bot detected.' });
  }
  if (!name || typeof name !== 'string' ||
      !contact || typeof contact !== 'string' ||
      !address || typeof address !== 'string') {
    return res.status(400).json({ error: 'Name, contact and address are required' });
  }

  const INTENTS  = ['pay', 'contact'];
  const safeIntent = INTENTS.includes(payment_intent) ? payment_intent : 'contact';
  const safeId   = parseId(product_id);
  if (!safeId) return res.status(400).json({ error: 'Valid product_id is required' });

  const { data: prod, error: prodErr } = await supabase
    .from('products')
    .select('id, name, price')
    .eq('id', safeId)
    .single();
  if (prodErr || !prod) return res.status(400).json({ error: 'Product not found' });

  const { error: orderErr } = await supabaseAdmin.from('orders').insert([{
    name:           sanitise(name, 200),
    contact:        sanitise(contact, 200),
    address:        sanitise(address, 500),
    size:           size ? sanitise(String(size), 50) : null,
    message:        message ? sanitise(String(message), 1000) : null,
    product_id:     prod.id,
    product_name:   prod.name,
    product_price:  prod.price,
    payment_intent: safeIntent,
    status: 'new',
  }]);
  if (orderErr) {
    console.error('Order save error:', orderErr.message);
    return res.status(500).json({ error: 'Could not save order, please try again.' });
  }

  res.json({ success: true });

  const safe = s => tgEscape(sanitise(String(s || ''), 200));
  const lines = [
    `🔔 <b>Jauns pasūtījums — Kotaaans</b>`,
    ``,
    `📦 Prece: <b>${safe(prod.name)}</b> — €${prod.price}`,
    `👤 Vārds: ${safe(name)}`,
    `📱 Kontakts: ${safe(contact)}`,
    `📍 Adrese: ${safe(address)}`,
  ];
  if (size)    lines.push(`📐 Izmērs: ${safe(size)}`);
  if (message) lines.push(`💬 Ziņojums: ${safe(message)}`);
  sendTelegramAsync(lines.join('\n'));
});

// ── ORDERS — GET (auth) ──────────────────────
app.get('/api/orders', requireAuth, async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(500);
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json(data);
});

// ── ORDERS — PATCH (auth) ────────────────────
app.patch('/api/orders/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const STATUSES = ['new', 'contacted', 'paid', 'shipped', 'done', 'cancelled'];
  const { status } = req.body;
  if (!STATUSES.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const { data, error } = await supabaseAdmin.from('orders').update({ status }).eq('id', id).select().single();
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json(data);
});

// ── ORDERS — DELETE (auth) ───────────────────
app.delete('/api/orders/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { error } = await supabaseAdmin.from('orders').delete().eq('id', id);
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json({ success: true });
});

// ── ACCOUNTING ───────────────────────────────
const ACC_CATEGORIES = [
  'sale', 'service', 'product', 'other',
  'materials', 'rent', 'equipment', 'ads', 'vsaoi', 'iin', 'refund',
];

app.get('/api/accounting/transactions', requireAuth, async (req, res) => {
  const { from, to, type } = req.query;
  if (from && !isValidDate(from)) return res.status(400).json({ error: 'Invalid from date' });
  if (to   && !isValidDate(to))   return res.status(400).json({ error: 'Invalid to date' });
  if (type && !['income', 'expense'].includes(type)) return res.status(400).json({ error: 'Invalid type' });
  let q = supabaseAdmin.from('accounting_transactions').select('*')
    .order('date', { ascending: false })
    .order('created_at', { ascending: false });
  if (from) q = q.gte('date', from);
  if (to)   q = q.lte('date', to);
  if (type) q = q.eq('type', type);
  const { data, error } = await q;
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json(data);
});

app.post('/api/accounting/transactions', requireAuth, async (req, res) => {
  const { type, amount, description, category, date } = req.body;
  if (!type || !amount || !description) return res.status(400).json({ error: 'type, amount, description required' });
  if (!['income', 'expense'].includes(type)) return res.status(400).json({ error: 'type must be income or expense' });
  const parsedAmount = parseFloat(amount);
  if (!Number.isFinite(parsedAmount) || parsedAmount <= 0 || parsedAmount > 10_000_000) {
    return res.status(400).json({ error: 'Invalid amount' });
  }
  const safeCategory = ACC_CATEGORIES.includes(category) ? category : 'other';
  const safeDate = isValidDate(date) ? date : new Date().toISOString().split('T')[0];
  const { data, error } = await supabaseAdmin
    .from('accounting_transactions')
    .insert([{ type, amount: parsedAmount, description: sanitise(description, 500), category: safeCategory, date: safeDate }])
    .select().single();
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.status(201).json(data);
});

app.delete('/api/accounting/transactions/:id', requireAuth, async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: 'Invalid ID' });
  const { error } = await supabaseAdmin.from('accounting_transactions').delete().eq('id', id);
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  res.json({ success: true });
});

app.get('/api/accounting/summary', requireAuth, async (req, res) => {
  const yearRaw = parseInt(req.query.year);
  const year = (!isNaN(yearRaw) && yearRaw >= 2020 && yearRaw <= 2100)
    ? yearRaw : new Date().getFullYear();
  const { data, error } = await supabaseAdmin
    .from('accounting_transactions')
    .select('type, amount, date, category')
    .gte('date', `${year}-01-01`)
    .lte('date', `${year}-12-31`);
  if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
  const income   = data.filter(t => t.type === 'income').reduce((s, t) => s + parseFloat(t.amount), 0);
  const expenses = data.filter(t => t.type === 'expense').reduce((s, t) => s + parseFloat(t.amount), 0);
  res.json({ year, income, expenses, balance: income - expenses, count: data.length });
});

// ── SETTINGS ─────────────────────────────────
const PUBLIC_SETTINGS_KEYS = new Set([
  'currency',
  'banner_enabled', 'banner_text', 'banner_color', 'banner_url',
  'instagram', 'telegram', 'email', 'city',
  'cat_Haircare', 'cat_Accessories', 'cat_Merch', 'cat_Other',
]);

app.get('/api/settings', async (req, res) => {
  try {
    const { data, error } = await supabase.from('site_settings').select('key, value');
    if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
    const obj = {};
    (data || []).forEach(r => {
      if (!PUBLIC_SETTINGS_KEYS.has(r.key)) return;
      try { obj[r.key] = JSON.parse(r.value); } catch { obj[r.key] = r.value; }
    });
    res.json(obj);
  } catch (e) { res.status(500).json({ error: 'Internal server error' }); }
});

app.get('/api/settings/admin', requireAuth, async (req, res) => {
  try {
    const { data, error } = await supabase.from('site_settings').select('key, value');
    if (error) { console.error(error.message); return res.status(500).json({ error: 'Internal server error' }); }
    const obj = {};
    (data || []).forEach(r => {
      if (!PUBLIC_SETTINGS_KEYS.has(r.key)) return;
      try { obj[r.key] = JSON.parse(r.value); } catch { obj[r.key] = r.value; }
    });
    res.json(obj);
  } catch (e) { res.status(500).json({ error: 'Internal server error' }); }
});

const ALLOWED_SETTINGS_KEYS = PUBLIC_SETTINGS_KEYS;

app.post('/api/settings', requireAuth, async (req, res) => {
  try {
    const updates = req.body;
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) return res.status(400).json({ error: 'Invalid body' });
    for (const [key, value] of Object.entries(updates)) {
      if (!isSafeKey(key)) return res.status(400).json({ error: 'Invalid key' });
      if (!ALLOWED_SETTINGS_KEYS.has(key)) return res.status(400).json({ error: `Unknown key: ${key}` });
      const serialized = JSON.stringify(value);
      if (serialized.length > 5000) return res.status(400).json({ error: `Value too large: ${key}` });
      await supabaseAdmin.from('site_settings')
        .upsert({ key, value: serialized, updated_at: new Date().toISOString() }, { onConflict: 'key' });
    }
    res.json({ success: true });
  } catch (e) { console.error(e.message); res.status(500).json({ error: 'Internal server error' }); }
});

// ── SERVER STATUS (test TG) ──────────────────
app.post('/api/server-status', requireAuth, async (req, res) => {
  try {
    await sendTelegramAsync(
      `📊 <b>Kotaaans Server</b>\n` +
      `✅ Online · Node ${tgEscape(process.version)}\n` +
      `🕐 ${tgEscape(new Date().toLocaleString('lv-LV'))}\n` +
      `Admin: <code>${tgEscape(req.user.email)}</code>`
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: 'Internal server error' }); }
});

// ── Static files ─────────────────────────────
// Exclude dotfiles, server-side files, and raw HTML templates from static
// serving. HTML files MUST come through routes that perform CSP-nonce
// replacement; serving them raw leaks the source and breaks CSP nonces.
app.use((req, res, next) => {
  const p = req.path;
  if (
    // any hidden dotfile/dir at any depth — covers .env, .env.local,
    // .env.example, .env.production, .git/, .gitignore, .npmrc, .DS_Store, etc.
    /(^|\/)\.[^/]+/.test(p) ||
    // server-side files and sensitive directories
    /(^|\/)(node_modules|supabase|server\.js|package(-lock)?\.json|dockerfile)(\/|$)/i.test(p) ||
    // raw HTML templates contain unreplaced %%NONCE%% — never serve as static
    /\.html$/i.test(p)
  ) {
    return res.status(404).end();
  }
  next();
});

app.use(express.static(path.join(__dirname), {
  index: false,
  dotfiles: 'deny',
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
}));

// Serve index.html for unmatched non-API GETs
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  if (/\.[a-zA-Z0-9]{1,8}$/.test(req.path)) return res.status(404).end();
  sendHtmlWithNonce(res, path.join(__dirname, 'index.html'));
});

// Global error handler — must be last
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err && err.message);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Internal server error' });
});

const server = app.listen(PORT, () => {
  console.log(`Kotaaans server running on port ${PORT}`);
});

function shutdown(sig) {
  console.log(`${sig} received, shutting down`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
