-- ═══════════════════════════════════════════════════════════════════════
--  Kotaaans Barbershop — Supabase / PostgreSQL schema
--
--  Run this once in the Supabase SQL editor (or via `supabase db push`)
--  to provision a fresh project. It creates every table the application
--  reads/writes, sensible indexes, and Row-Level Security policies that
--  match how the server uses the anon vs. service-role keys:
--
--    • Public (anon) key  → read-only access to public catalog data.
--    • Service-role key    → full access from the server (bypasses RLS).
--
--  Derived from the data-access patterns in server.js.
-- ═══════════════════════════════════════════════════════════════════════

-- ── Extensions ─────────────────────────────────────────────────────────
create extension if not exists "pgcrypto";

-- ── Services (haircut / beard / extra catalog) ─────────────────────────
create table if not exists public.services (
  id          bigint generated always as identity primary key,
  name        text        not null,
  description text        default '',
  time_label  text        default '',
  price       numeric(10,2) not null default 0,
  category    text        not null default 'hair'
              check (category in ('hair', 'beard', 'extra')),
  sort_order  integer     not null default 0,
  img_url     text,
  created_at  timestamptz not null default now()
);
create index if not exists services_category_sort_idx
  on public.services (category, sort_order, created_at);

-- ── Products (shop items) ──────────────────────────────────────────────
create table if not exists public.products (
  id              bigint generated always as identity primary key,
  name            text          not null,
  price           numeric(10,2) not null,
  description     text          default '',
  emoji           text          default '📦',
  img_url         text,
  gallery         jsonb         not null default '[]'::jsonb,
  category        text          not null default 'Other'
                  check (category in ('Haircare', 'Accessories', 'Merch', 'Other')),
  available_sizes jsonb         not null default '[]'::jsonb,
  tags            jsonb         not null default '[]'::jsonb,
  payment_url     text,
  is_preorder     boolean       not null default false,
  sort_order      integer       not null default 0,
  created_at      timestamptz   not null default now()
);
create index if not exists products_created_idx
  on public.products (created_at desc);

-- ── Portfolio photos ───────────────────────────────────────────────────
create table if not exists public.portfolio_photos (
  id         bigint generated always as identity primary key,
  img_url    text        not null,
  sort_order integer     not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists portfolio_sort_idx
  on public.portfolio_photos (sort_order asc);

-- ── Orders ─────────────────────────────────────────────────────────────
create table if not exists public.orders (
  id             bigint generated always as identity primary key,
  name           text          not null,
  contact        text          not null,
  address        text          not null,
  size           text,
  message        text,
  product_id     bigint        references public.products (id) on delete set null,
  product_name   text,
  product_price  numeric(10,2),
  payment_intent text          not null default 'contact'
                 check (payment_intent in ('pay', 'contact')),
  status         text          not null default 'new'
                 check (status in ('new','contacted','paid','shipped','done','cancelled')),
  created_at     timestamptz   not null default now()
);
create index if not exists orders_created_idx
  on public.orders (created_at desc);

-- ── Accounting transactions ────────────────────────────────────────────
create table if not exists public.accounting_transactions (
  id          bigint generated always as identity primary key,
  type        text          not null check (type in ('income', 'expense')),
  amount      numeric(12,2) not null check (amount > 0),
  description text          not null,
  category    text          not null default 'other',
  date        date          not null default current_date,
  created_at  timestamptz   not null default now()
);
create index if not exists accounting_date_idx
  on public.accounting_transactions (date desc, created_at desc);

-- ── Site settings (key/value, value is a JSON string) ──────────────────
create table if not exists public.site_settings (
  key        text primary key,
  value      text        not null,
  updated_at timestamptz not null default now()
);

-- ═══════════════════════════════════════════════════════════════════════
--  Row-Level Security
--
--  The service-role key used by the server bypasses RLS entirely, so we
--  only need policies that grant the PUBLIC (anon) role read access to
--  catalog data. Orders, accounting and settings stay server-only.
-- ═══════════════════════════════════════════════════════════════════════
alter table public.services               enable row level security;
alter table public.products               enable row level security;
alter table public.portfolio_photos       enable row level security;
alter table public.orders                  enable row level security;
alter table public.accounting_transactions enable row level security;
alter table public.site_settings          enable row level security;

-- Public read-only access to the catalog
create policy "public read services"  on public.services
  for select using (true);
create policy "public read products"  on public.products
  for select using (true);
create policy "public read portfolio" on public.portfolio_photos
  for select using (true);

-- The /api/order endpoint looks up a product with the anon client before
-- inserting via the service role, so products read access above covers it.
-- site_settings is read with the anon client too; the server filters which
-- keys are exposed, so a blanket public-read policy is acceptable:
create policy "public read settings" on public.site_settings
  for select using (true);

-- orders + accounting_transactions: no anon policies → server-only.

-- ═══════════════════════════════════════════════════════════════════════
--  Storage
--
--  Create a PUBLIC bucket named "product-images" (Dashboard → Storage,
--  or the statement below). The server uploads validated images here with
--  the service-role key and serves their public URLs.
--
--  WRITE ACCESS IS SERVER-ONLY. All image uploads (products, services AND
--  portfolio) go through the Node server, which validates the file
--  (magic bytes, type, size) and writes with the service-role key —
--  service-role bypasses RLS, so NO write policy on storage.objects is
--  needed for the app to work.
--
--  Because storage.objects has RLS enabled by default, the absence of any
--  insert/update/delete policy means anon/authenticated clients CANNOT
--  write to the bucket — which is exactly what we want. Public reads work
--  regardless, via the bucket's public flag.
--
--  ⚠️  If you previously added a permissive policy to allow direct
--      browser uploads (e.g. "authenticated can insert into product-images"),
--      REMOVE it in Dashboard → Storage → Policies. Otherwise any signed-up
--      user could upload arbitrary files straight to this public bucket,
--      bypassing the server's content validation.
-- ═══════════════════════════════════════════════════════════════════════
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

-- ═══════════════════════════════════════════════════════════════════════
--  Optional: default site settings seed
-- ═══════════════════════════════════════════════════════════════════════
insert into public.site_settings (key, value) values
  ('shop_open',       'true'),
  ('currency',        '"EUR"'),
  ('default_lang',    '"lv"'),
  ('buy_now_enabled', 'false')
on conflict (key) do nothing;
